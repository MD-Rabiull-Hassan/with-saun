<?php
    $title = "Home Page";
    include('includes/header.php'); 
?>
        
    <h1>Hello world</h1>



    
<?php include('includes/footer.php'); ?>