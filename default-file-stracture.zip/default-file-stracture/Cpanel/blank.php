<?php include('includes/header.php'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        

    </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->


<?php include('includes/footer.php'); ?>